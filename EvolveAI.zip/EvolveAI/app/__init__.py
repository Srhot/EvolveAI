"""EvolveAI Gradio application."""
