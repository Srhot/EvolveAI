"""EvolveAI test suite."""
